# Architecture of AWS RDS

## Specs