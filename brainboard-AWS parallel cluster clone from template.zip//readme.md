# Parallel cluster technical stack

## Networking
- [x] VPC to restrict access to the compute resources
- [x] Security group: it allows all the traffic to go out from the resources to internet and blocks the incoming traffic allowing only HTTPs

## Compute
- [x] Auto-scaling group: allows you to scale the capacity when needed.
  - [x] You have 2 variables to control the min and max capacity of the ASG
  - [x] It uses C5n machines for the execution
- [x] Launch configuration template: allows you to scale the capacity based on definition set in the configuration

## Database
- [x] Dynamodb table: with basic configuration. It is connected to the nodes and able to communicate with them

## System manager session
- [x] IAM role: the AWS role associated with SSM activation. It defines the actions allowed for users
- [x] SSM activation
- [x] SSM document
- [ ] Cusotm configuration that meets the clients' environements

# Post-provisioning
After the cloud resources are provioned you need to install the cluster and use the information of the stack created.

N.B:
- This stack is based on scaling VMs to handle more loads
- You have the possibility to use batch processing or Fargate to use containers
- This architecture contains basic and default configuration to provision a POC environment